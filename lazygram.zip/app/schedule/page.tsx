import type { Metadata } from "next"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ScheduleCalendarView from "@/components/schedule/schedule-calendar-view"
import ScheduleListView from "@/components/schedule/schedule-list-view"
import PageHeader from "@/components/layout/page-header"
import { getScheduledImages, getImages } from "@/app/actions/image-actions"

export const metadata: Metadata = {
  title: "Schedule - Lazygram",
  description: "Manage and organize your Instagram posting schedule",
}

export default async function SchedulePage() {
  // Fetch scheduled and unscheduled images
  const scheduledImages = await getScheduledImages()
  const allImages = await getImages()

  // Filter for unscheduled images (not scheduled and not posted)
  const unscheduledImages = allImages.filter((img) => !img.scheduled && !img.postedAt)

  return (
    <div className="space-y-6">
      <PageHeader title="Schedule Manager" description="Organize your Instagram posts with drag-and-drop scheduling" />

      <Tabs defaultValue="calendar" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2 mb-6">
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          <TabsTrigger value="list">List View</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-4">
          <ScheduleCalendarView scheduledImages={scheduledImages} unscheduledImages={unscheduledImages} />
        </TabsContent>

        <TabsContent value="list" className="space-y-4">
          <ScheduleListView scheduledImages={scheduledImages} unscheduledImages={unscheduledImages} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

