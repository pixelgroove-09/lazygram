import { type NextRequest, NextResponse } from "next/server"
import { getInstagramFromDB } from "@/lib/db"
import { postToInstagram, validateToken } from "@/lib/instagram"
import { mockPostToInstagram } from "@/lib/instagram-mock"
import { isMockModeEnabled } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    const { imageUrl, caption } = await request.json()

    if (!imageUrl) {
      return NextResponse.json({ error: "No image URL provided" }, { status: 400 })
    }

    if (!caption) {
      return NextResponse.json({ error: "No caption provided" }, { status: 400 })
    }

    // Get Instagram account info
    const instagramAccount = await getInstagramFromDB()

    if (!instagramAccount.connected) {
      return NextResponse.json({ error: "Instagram account not connected" }, { status: 400 })
    }

    // Check if we should use mock mode
    const useMock = isMockModeEnabled()
    console.log("Using mock mode for posting:", useMock)

    if (useMock) {
      console.log("Using mock Instagram posting")

      // Use mock posting
      const mockResult = await mockPostToInstagram(imageUrl, caption)

      if (!mockResult.success) {
        return NextResponse.json(
          {
            error: "Failed to post to Instagram (mock)",
            details: mockResult.error,
          },
          { status: 500 },
        )
      }

      return NextResponse.json({
        success: true,
        message: "Posted to Instagram successfully (mock)",
        postId: mockResult.postId,
      })
    }

    // Check if we have the necessary environment variables for real Instagram API
    if (!process.env.INSTAGRAM_APP_ID || !process.env.INSTAGRAM_APP_SECRET) {
      return NextResponse.json(
        {
          error: "Instagram API credentials not configured",
          details: "INSTAGRAM_APP_ID and INSTAGRAM_APP_SECRET environment variables must be set for live mode",
        },
        { status: 500 },
      )
    }

    // Validate the access token
    console.log("Validating Instagram access token")
    const isTokenValid = await validateToken(instagramAccount.accessToken)

    if (!isTokenValid) {
      return NextResponse.json({ error: "Instagram access token is invalid or expired" }, { status: 401 })
    }

    try {
      console.log("Posting to Instagram using real API")
      console.log("Account ID:", instagramAccount.accountId)

      // Post to Instagram using the Graph API
      const postId = await postToInstagram(instagramAccount.accessToken, instagramAccount.accountId, imageUrl, caption)

      console.log("Successfully posted to Instagram with ID:", postId)

      return NextResponse.json({
        success: true,
        message: "Posted to Instagram successfully",
        postId: postId,
      })
    } catch (postError) {
      console.error("Error posting to Instagram:", postError)
      return NextResponse.json(
        {
          error: "Failed to post to Instagram",
          details: postError.message,
          stack: process.env.NODE_ENV === "development" ? postError.stack : undefined,
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Instagram posting error:", error)
    return NextResponse.json(
      {
        error: "Failed to post to Instagram",
        message: error.message || "Unknown error",
        stack: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}

