// app/api/cron/post/route.ts

import { NextResponse } from "next/server"
import { getScheduledImagesFromDB, getScheduleFromDB, markImageAsPosted, getInstagramFromDB } from "@/lib/db"
import { postToInstagram, validateToken } from "@/lib/instagram"
import { mockPostToInstagram } from "@/lib/instagram-mock"
import { instagramConfig } from "@/lib/config"

export const dynamic = "force-dynamic"

export async function GET(request: Request) {
  // Add a secret key check for additional security (optional)
  const authHeader = request.headers.get("authorization")
  const expectedKey = process.env.CRON_SECRET_KEY

  // If CRON_SECRET_KEY is set, verify it (skip check if not set)
  if (expectedKey && (!authHeader || authHeader !== `Bearer ${expectedKey}`)) {
    console.warn("Unauthorized cron job request - missing or invalid secret key")
    return NextResponse.json({ error: "Unauthorized", message: "Invalid or missing secret key" }, { status: 401 })
  }

  try {
    console.log("Running Instagram posting cron job:", new Date().toISOString())

    // Check if automatic posting is enabled
    const scheduleSettings = await getScheduleFromDB()

    if (!scheduleSettings.enabled) {
      console.log("Automatic posting is disabled")
      return NextResponse.json({
        success: true,
        message: "Automatic posting is disabled",
        posted: 0,
      })
    }

    // Get Instagram account info
    const instagramAccount = await getInstagramFromDB()

    if (!instagramAccount.connected) {
      console.log("Instagram account not connected")
      return NextResponse.json({
        success: false,
        message: "Instagram account not connected",
        posted: 0,
      })
    }

    // Check if we should use mock mode based on config
    const useMock = instagramConfig.useMockMode
    console.log("Using mock mode:", useMock ? "Yes" : "No")

    // If not using mock, validate the token
    if (!useMock) {
      console.log("Validating Instagram access token")
      const isTokenValid = await validateToken(instagramAccount.accessToken)

      if (!isTokenValid) {
        console.error("Instagram access token is invalid or expired")
        return NextResponse.json({
          success: false,
          message: "Instagram access token is invalid or expired",
          posted: 0,
        })
      }
    }

    // Get scheduled images that are due to be posted
    const scheduledImages = await getScheduledImagesFromDB()
    const now = new Date()

    console.log(`Found ${scheduledImages.length} scheduled images`)

    // Filter images that are due to be posted
    const dueImages = scheduledImages.filter((image) => {
      if (!image.scheduledTime) return false
      const scheduledTime = new Date(image.scheduledTime)
      return scheduledTime <= now
    })

    console.log(`Found ${dueImages.length} images due for posting`)

    if (dueImages.length === 0) {
      return NextResponse.json({
        success: true,
        message: "No images due for posting",
        posted: 0,
      })
    }

    // Sort by scheduled time (oldest first) to ensure we post in the correct order
    dueImages.sort((a, b) => {
      return new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime()
    })

    // Post the first due image
    const imageToPost = dueImages[0]
    console.log(`Posting image ID: ${imageToPost.id}, scheduled for: ${imageToPost.scheduledTime}`)

    // Format caption with hashtags
    const caption =
      imageToPost.hashtags && imageToPost.hashtags.length > 0
        ? `${imageToPost.caption}

${imageToPost.hashtags.join(" ")}`
        : imageToPost.caption

    try {
      let postId

      if (useMock) {
        console.log("Using mock Instagram posting for scheduled post")
        const mockResult = await mockPostToInstagram(imageToPost.url, caption)

        if (!mockResult.success) {
          throw new Error(mockResult.error || "Mock posting failed")
        }

        postId = mockResult.postId
        console.log("Mock post successful with ID:", postId)
      } else {
        // Post to Instagram using the Graph API
        console.log("Posting to Instagram via Graph API")

        // Add additional logging
        console.log("Instagram Account ID:", instagramAccount.accountId)
        console.log("Image URL:", imageToPost.url)
        console.log("Caption length:", caption.length)

        postId = await postToInstagram(
          instagramAccount.accessToken,
          instagramAccount.accountId,
          imageToPost.url,
          caption,
        )

        console.log("Post successful with ID:", postId)
      }

      // Mark the image as posted
      await markImageAsPosted(imageToPost.id)
      console.log(`Marked image ${imageToPost.id} as posted`)

      return NextResponse.json({
        success: true,
        message: useMock ? "Posted to Instagram successfully (mock)" : "Posted to Instagram successfully",
        posted: 1,
        imageId: imageToPost.id,
        postId: postId,
      })
    } catch (postError) {
      console.error("Error posting to Instagram:", postError)
      return NextResponse.json({
        success: false,
        message: `Failed to post to Instagram: ${postError.message}`,
        posted: 0,
        error: postError.message,
        imageId: imageToPost.id,
      })
    }
  } catch (error) {
    console.error("Cron job error:", error)
    return NextResponse.json(
      {
        error: "Failed to run cron job",
        message: error.message,
      },
      { status: 500 },
    )
  }
}

