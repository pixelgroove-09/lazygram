import { type NextRequest, NextResponse } from "next/server"
import { getInstagramAuthUrl } from "@/lib/instagram"
import { isMockModeEnabled } from "@/lib/config"

export async function GET(request: NextRequest) {
  try {
    console.log("Instagram auth route called")
    console.log("Environment mode:", process.env.NODE_ENV)
    console.log("USE_MOCK_INSTAGRAM:", process.env.USE_MOCK_INSTAGRAM)

    // Use the helper function to determine mock mode
    const useMock = isMockModeEnabled()
    console.log("Using mock mode:", useMock)

    if (useMock) {
      console.log("Redirecting to mock Instagram callback")
      const mockCallbackUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/instagram/mock-callback`
      console.log("Mock callback URL:", mockCallbackUrl)

      // Return a redirect response
      return NextResponse.redirect(mockCallbackUrl)
    }

    // Real Instagram auth flow
    console.log("Using real Instagram authentication")

    // Check if environment variables are set
    if (!process.env.INSTAGRAM_APP_ID) {
      console.error("INSTAGRAM_APP_ID environment variable is not set")
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/settings?error=configuration_error&error_description=${encodeURIComponent("Instagram App ID is not configured")}`,
      )
    }

    if (!process.env.INSTAGRAM_APP_SECRET) {
      console.error("INSTAGRAM_APP_SECRET environment variable is not set")
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/settings?error=configuration_error&error_description=${encodeURIComponent("Instagram App Secret is not configured")}`,
      )
    }

    if (!process.env.NEXT_PUBLIC_APP_URL) {
      console.error("NEXT_PUBLIC_APP_URL environment variable is not set")
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL || ""}/settings?error=configuration_error&error_description=${encodeURIComponent("App URL is not configured")}`,
      )
    }

    try {
      const authUrl = await getInstagramAuthUrl()
      console.log("Generated Instagram auth URL:", authUrl)

      // Redirect directly to the auth URL
      return NextResponse.redirect(authUrl)
    } catch (authUrlError: any) {
      console.error("Error generating Instagram auth URL:", authUrlError)
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/settings?error=auth_url_generation_failed&error_description=${encodeURIComponent(authUrlError.message || "Failed to generate Instagram authorization URL")}`,
      )
    }
  } catch (error: any) {
    console.error("Instagram auth error:", error)

    // Return a redirect with detailed error information
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/settings?error=auth_init_failed&error_description=${encodeURIComponent(error.message || "Unknown error")}&error_debug=${encodeURIComponent(
        JSON.stringify({
          message: error.message,
          stack: error.stack,
          name: error.name,
        }),
      )}`,
    )
  }
}

