import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { mockMode } = await request.json()

    // In a real application, you would update a database setting
    // For this example, we'll update the environment variable

    // This is a simplified example - in a real app, you would use
    // a more robust method to update configuration

    // For now, we'll just return success and let the client-side
    // handle the state

    return NextResponse.json({
      success: true,
      mockMode,
      message: `Mock mode ${mockMode ? "enabled" : "disabled"}`,
    })
  } catch (error) {
    console.error("Error updating mock mode:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update mock mode",
        message: error.message,
      },
      { status: 500 },
    )
  }
}

