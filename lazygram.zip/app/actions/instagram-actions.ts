"use server"

import { getInstagramFromDB, updateInstagramInDB } from "@/lib/db"
import { validateToken } from "@/lib/instagram"
import { isMockModeEnabled } from "@/lib/config"

export async function getInstagramSettings() {
  try {
    console.log("Getting Instagram settings from DB")

    // Check if we're in mock mode
    const useMock = isMockModeEnabled()
    console.log("Using mock mode:", useMock)

    try {
      const settings = await getInstagramFromDB()

      // If connected, validate the token (skip in mock mode)
      if (settings.connected && settings.accessToken && !useMock) {
        const isTokenValid = await validateToken(settings.accessToken)

        // If token is invalid, update the settings
        if (!isTokenValid) {
          console.warn("Instagram token is invalid, marking as disconnected")
          settings.connected = false
        }
      }

      return settings
    } catch (dbError) {
      console.error("Database error when getting Instagram settings:", dbError)

      // Return default settings if there's a database error
      return {
        connected: false,
        accountName: "",
        accountId: "",
        accessToken: "",
        profilePicture: "",
      }
    }
  } catch (error) {
    console.error("Error fetching Instagram settings:", error)
    throw new Error("Failed to fetch Instagram settings: " + (error.message || "Unknown error"))
  }
}

export async function updateInstagramSettings(settings: {
  connected: boolean
  accountName: string
  accountId: string
  accessToken?: string
  profilePicture?: string
}) {
  try {
    console.log("Updating Instagram settings in DB")
    await updateInstagramInDB(settings)
    return { success: true }
  } catch (error) {
    console.error("Error updating Instagram settings:", error)
    throw new Error("Failed to update Instagram settings: " + (error.message || "Unknown error"))
  }
}

export async function disconnectInstagram() {
  try {
    console.log("Disconnecting Instagram account")
    await updateInstagramInDB({
      connected: false,
      accountName: "",
      accountId: "",
      accessToken: "",
      profilePicture: "",
    })

    return { success: true }
  } catch (error) {
    console.error("Error disconnecting from Instagram:", error)
    throw new Error("Failed to disconnect from Instagram: " + (error.message || "Unknown error"))
  }
}

