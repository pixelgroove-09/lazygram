"use client"

import { PageHeader } from "@/components/layout/page-header"

export default function DashboardHeader() {
  return <PageHeader title="Dashboard" description="Manage your Instagram content and scheduling" className="mb-8" />
}

