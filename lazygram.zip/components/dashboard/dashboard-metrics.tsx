import { Calendar, Clock, Image } from "lucide-react"
import Link from "next/link"

interface DashboardMetricsProps {
  scheduledCount: number
  postedCount: number
  uploadedCount: number
}

export default function DashboardMetrics({ scheduledCount, postedCount, uploadedCount }: DashboardMetricsProps) {
  const metrics = [
    {
      title: "Scheduled Posts",
      value: scheduledCount,
      description: "Posts waiting to be published",
      icon: <Calendar className="h-5 w-5 text-primary-500" />,
      href: "/schedule",
      color: "bg-primary-50 hover:bg-primary-100",
      textColor: "text-primary-700",
    },
    {
      title: "Posted",
      value: postedCount,
      description: "Successfully published posts",
      icon: <Clock className="h-5 w-5 text-secondary-500" />,
      href: "/dashboard?tab=activity",
      color: "bg-secondary-50 hover:bg-secondary-100",
      textColor: "text-secondary-700",
    },
    {
      title: "Uploaded Images",
      value: uploadedCount,
      description: "Images ready to be scheduled",
      icon: <Image className="h-5 w-5 text-indigo-500" />,
      href: "/upload",
      color: "bg-indigo-50 hover:bg-indigo-100",
      textColor: "text-indigo-700",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {metrics.map((metric) => (
        <Link key={metric.title} href={metric.href}>
          <div className={`lazygram-card p-6 transition-all duration-200 cursor-pointer ${metric.color}`}>
            <div className="flex justify-between items-start">
              <div>
                <p className={`text-sm font-semibold ${metric.textColor}`}>{metric.title}</p>
                <h3 className="text-3xl font-bold mt-2">{metric.value}</h3>
                <p className="text-sm text-gray-600 mt-1">{metric.description}</p>
              </div>
              <div className="p-3 rounded-full bg-white shadow-sm">{metric.icon}</div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}

