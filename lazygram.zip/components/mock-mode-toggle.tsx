"use client"

import { useState, useEffect } from "react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { isMockModeEnabled } from "@/lib/config"

export default function MockModeToggle() {
  const [mockMode, setMockMode] = useState(true)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setMockMode(isMockModeEnabled())
  }, [])

  const handleToggle = async (checked: boolean) => {
    try {
      setLoading(true)

      // Update the environment variable via API
      const response = await fetch("/api/config/mock-mode", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ mockMode: checked }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Failed to update mock mode")
      }

      setMockMode(checked)

      toast({
        title: `${checked ? "Mock" : "Live"} mode enabled`,
        description: checked ? "Instagram operations will be simulated" : "Instagram operations will use the real API",
      })

      // Refresh the page to apply changes
      router.refresh()
    } catch (error) {
      console.error("Failed to toggle mock mode:", error)
      toast({
        title: "Failed to update mode",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex items-center space-x-2">
      <Switch id="mock-mode" checked={mockMode} onCheckedChange={handleToggle} disabled={loading} />
      <Label htmlFor="mock-mode" className="cursor-pointer">
        {loading ? (
          <span className="flex items-center">
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Updating...
          </span>
        ) : (
          <span>Mock Mode {mockMode ? "Enabled" : "Disabled"}</span>
        )}
      </Label>
    </div>
  )
}

