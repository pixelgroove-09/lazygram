"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2, ImageIcon, Send, AlertCircle, Check, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { getInstagramSettings } from "@/app/actions/instagram-actions"
import { Progress } from "@/components/ui/progress"
import { isMockModeEnabled } from "@/lib/config"

export default function InstagramTestPost() {
  const [loading, setLoading] = useState(false)
  const [caption, setCaption] = useState("")
  const [image, setImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState<"idle" | "uploading" | "processing" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [errorDetails, setErrorDetails] = useState<string | null>(null)
  const [postId, setPostId] = useState<string | null>(null)
  const [connected, setConnected] = useState(false)
  const [accountName, setAccountName] = useState("")
  const [isMockMode, setIsMockMode] = useState(true)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Check Instagram connection status on mount
  useEffect(() => {
    const checkConnection = async () => {
      try {
        const settings = await getInstagramSettings()
        setConnected(settings.connected)
        setAccountName(settings.accountName)
        setIsMockMode(isMockModeEnabled())
      } catch (error) {
        console.error("Failed to check Instagram connection:", error)
      }
    }

    checkConnection()
  }, [])

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setImage(file)

      // Create image preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!connected) {
      toast({
        title: "Not connected",
        description: "Please connect your Instagram account first.",
        variant: "destructive",
      })
      return
    }

    if (!image) {
      toast({
        title: "Image required",
        description: "Please select an image to post.",
        variant: "destructive",
      })
      return
    }

    if (!caption.trim()) {
      toast({
        title: "Caption required",
        description: "Please enter a caption for your post.",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)
      setStatus("uploading")
      setProgress(10)
      setErrorMessage(null)
      setErrorDetails(null)

      // First, upload the image to get a URL
      const formData = new FormData()
      formData.append("file", image)

      console.log("Uploading image...")
      const uploadResponse = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (!uploadResponse.ok) {
        const errorData = await uploadResponse.json()
        throw new Error(errorData.message || "Failed to upload image")
      }

      const uploadResult = await uploadResponse.json()
      console.log("Image uploaded successfully:", uploadResult.url)
      setProgress(50)
      setStatus("processing")

      // Now post to Instagram
      console.log("Posting to Instagram...")
      const postResponse = await fetch("/api/instagram/post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          imageUrl: uploadResult.url,
          caption: caption,
        }),
      })

      if (!postResponse.ok) {
        const errorData = await postResponse.json()
        console.error("Instagram post error:", errorData)
        throw new Error(errorData.error || errorData.message || "Failed to post to Instagram")
      }

      const postResult = await postResponse.json()
      console.log("Post successful:", postResult)
      setProgress(100)
      setStatus("success")
      setPostId(postResult.postId)

      toast({
        title: "Post successful",
        description: isMockMode
          ? "Test post was simulated successfully (mock mode)"
          : "Your post was published to Instagram successfully.",
      })

      // Reset form after successful post
      setCaption("")
      setImage(null)
      setImagePreview(null)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    } catch (error) {
      console.error("Failed to post to Instagram:", error)
      setStatus("error")

      if (error instanceof Error) {
        setErrorMessage(error.message)
        setErrorDetails(error.stack || null)
      } else {
        setErrorMessage("An unknown error occurred")
      }

      toast({
        title: "Post failed",
        description: error instanceof Error ? error.message : "Failed to post to Instagram",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Test Instagram Post</CardTitle>
        <CardDescription>Create and publish a test post to verify your Instagram connection</CardDescription>
      </CardHeader>
      <CardContent>
        {!connected ? (
          <Alert variant="warning" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Not Connected</AlertTitle>
            <AlertDescription>
              Please connect your Instagram account in the settings before testing posts.
            </AlertDescription>
          </Alert>
        ) : (
          <Alert variant="success" className="mb-4">
            <Check className="h-4 w-4" />
            <AlertTitle>Connected to Instagram</AlertTitle>
            <AlertDescription>
              Ready to post to @{accountName} {isMockMode && "(Mock Mode)"}
            </AlertDescription>
          </Alert>
        )}

        {!isMockMode && (
          <Alert className="mb-4 bg-green-50 border-green-200">
            <Info className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Live Mode Active</AlertTitle>
            <AlertDescription className="text-green-700">
              You are using the real Instagram API. Your test post will be published to your actual Instagram account.
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="image">Image</Label>
            <div className="flex items-center gap-4">
              <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} disabled={loading}>
                <ImageIcon className="h-4 w-4 mr-2" />
                Select Image
              </Button>
              <Input
                ref={fileInputRef}
                id="image"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageChange}
                disabled={loading}
              />
              {imagePreview && (
                <div className="relative h-16 w-16 rounded-md overflow-hidden bg-muted">
                  <img src={imagePreview || "/placeholder.svg"} alt="Preview" className="h-full w-full object-cover" />
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="caption">Caption</Label>
            <Textarea
              id="caption"
              placeholder="Enter your post caption..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="min-h-[100px]"
              disabled={loading}
            />
          </div>

          {status !== "idle" && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>
                  {status === "uploading" && "Uploading image..."}
                  {status === "processing" && "Processing post..."}
                  {status === "success" && "Post successful!"}
                  {status === "error" && "Post failed"}
                </span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          {status === "error" && errorMessage && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription className="space-y-2">
                <p>{errorMessage}</p>
                {errorDetails && (
                  <details className="text-xs mt-2">
                    <summary>Technical Details</summary>
                    <pre className="mt-2 whitespace-pre-wrap bg-destructive/10 p-2 rounded">{errorDetails}</pre>
                  </details>
                )}
              </AlertDescription>
            </Alert>
          )}

          {status === "success" && (
            <Alert variant="success">
              <Check className="h-4 w-4" />
              <AlertTitle>Post Successful</AlertTitle>
              <AlertDescription>
                {isMockMode
                  ? `Your test post was simulated successfully (mock mode). Post ID: ${postId}`
                  : `Your post was published to Instagram successfully. Post ID: ${postId}`}
              </AlertDescription>
            </Alert>
          )}
        </form>
      </CardContent>
      <CardFooter>
        <Button type="submit" className="w-full" disabled={loading || !connected} onClick={handleSubmit}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {status === "uploading" ? "Uploading..." : "Processing..."}
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Post to Instagram {isMockMode && "(Mock)"}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

