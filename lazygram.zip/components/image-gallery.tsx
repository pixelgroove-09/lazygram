"use client"

import { DialogTrigger } from "@/components/ui/dialog"

import { useState, useEffect } from "react"
import { Edit, Save, Trash2, Calendar, Instagram, Loader2, ImagePlus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { toast } from "@/components/ui/use-toast"
import { getImages, updateCaption, deleteImage, scheduleImage, unscheduleImage } from "@/app/actions/image-actions"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useGallery } from "@/contexts/gallery-context"

interface ImageItem {
  id: string
  url: string
  caption: string
  hashtags: string[]
  createdAt: string
  scheduled?: boolean
  scheduledTime?: string
}

// Helper function to clean up captions by removing numbering and prefixes
function cleanCaption(text: string): string {
  if (!text) return ""
  // Remove patterns like "1. Caption:", "1.", "2.", etc.
  return text
    .replace(/^\d+\.\s*(Caption:\s*)?/i, "") // Remove starting numbers and "Caption:" prefix
    .replace(/\s*\d+\.\s*$/g, "") // Remove trailing numbers like "2." at the end
    .trim()
}

export default function ImageGallery() {
  const { refreshTrigger } = useGallery()
  const [images, setImages] = useState<ImageItem[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editedCaption, setEditedCaption] = useState("")
  const [editedHashtags, setEditedHashtags] = useState("")
  const [schedulingId, setSchedulingId] = useState<string | null>(null)
  const [scheduledTime, setScheduledTime] = useState("")
  const [postingId, setPostingId] = useState<string | null>(null)

  useEffect(() => {
    loadImages()
  }, [refreshTrigger]) // Reload when refreshTrigger changes

  const loadImages = async () => {
    try {
      setLoading(true)
      const data = await getImages()
      setImages(data)
    } catch (error) {
      console.error("Failed to load images:", error)
      toast({
        title: "Error loading images",
        description: "Could not load your images. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = (image: ImageItem) => {
    setEditingId(image.id)
    setEditedCaption(image.caption)
    setEditedHashtags(image.hashtags.join(" "))
  }

  const handleSave = async (id: string) => {
    try {
      const hashtags = editedHashtags
        .split(/\s+/)
        .map((tag) => (tag.startsWith("#") ? tag : `#${tag}`))
        .filter(Boolean)

      await updateCaption(id, editedCaption, hashtags)

      setImages(images.map((img) => (img.id === id ? { ...img, caption: editedCaption, hashtags } : img)))

      setEditingId(null)
      toast({
        title: "Caption updated",
        description: "Your caption has been updated successfully.",
      })
    } catch (error) {
      console.error("Failed to update caption:", error)
      toast({
        title: "Update failed",
        description: "Could not update the caption. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this image?")) return

    try {
      await deleteImage(id)
      setImages(images.filter((img) => img.id !== id))
      toast({
        title: "Image deleted",
        description: "The image has been deleted successfully.",
      })
    } catch (error) {
      console.error("Failed to delete image:", error)
      toast({
        title: "Delete failed",
        description: "Could not delete the image. Please try again.",
        variant: "destructive",
      })
    }
  }

  const openScheduleDialog = (image: ImageItem) => {
    setSchedulingId(image.id)

    // Set default time to tomorrow at noon
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    tomorrow.setHours(12, 0, 0, 0)

    setScheduledTime(tomorrow.toISOString().slice(0, 16)) // Format: YYYY-MM-DDTHH:MM
  }

  const handleSchedule = async () => {
    if (!schedulingId) return

    try {
      await scheduleImage(schedulingId, new Date(scheduledTime).toISOString())

      setImages(images.map((img) => (img.id === schedulingId ? { ...img, scheduled: true, scheduledTime } : img)))

      setSchedulingId(null)
      toast({
        title: "Post scheduled",
        description: "Your post has been scheduled successfully.",
      })
    } catch (error) {
      console.error("Failed to schedule post:", error)
      toast({
        title: "Scheduling failed",
        description: "Could not schedule the post. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handlePostNow = async (image: ImageItem) => {
    if (!confirm("Are you sure you want to post this image to Instagram now?")) return

    try {
      setPostingId(image.id)

      // Call the API to post to Instagram
      const response = await fetch("/api/instagram/post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          imageUrl: image.url,
          caption: `${cleanCaption(image.caption)}\n\n${image.hashtags.join(" ")}`,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to post to Instagram")
      }

      // Mark the image as posted in our local state
      setImages(
        images.map((img) =>
          img.id === image.id ? { ...img, scheduled: false, postedAt: new Date().toISOString() } : img,
        ),
      )

      // If the image was scheduled, unschedule it
      if (image.scheduled) {
        await unscheduleImage(image.id)
      }

      toast({
        title: "Posted to Instagram",
        description: "Your image has been posted to Instagram successfully.",
      })
    } catch (error) {
      console.error("Failed to post to Instagram:", error)
      toast({
        title: "Posting failed",
        description: error instanceof Error ? error.message : "Could not post to Instagram. Please try again.",
        variant: "destructive",
      })
    } finally {
      setPostingId(null)
    }
  }

  // Render skeleton loading UI
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="lazygram-card border-0">
            <div className="aspect-square relative">
              <Skeleton className="h-full w-full rounded-t-2xl" />
            </div>
            <CardContent className="p-4">
              <div className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <div className="flex flex-wrap gap-1">
                  {[1, 2, 3, 4, 5].map((tag) => (
                    <Skeleton key={tag} className="h-6 w-16 rounded-full" />
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between p-4 pt-0">
              <div className="flex space-x-2">
                <Skeleton className="h-9 w-20 rounded-full" />
                <Skeleton className="h-9 w-24 rounded-full" />
              </div>
              <Skeleton className="h-9 w-9 rounded-full" />
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  if (images.length === 0) {
    return (
      <div className="text-center py-16 bg-background rounded-2xl border border-gray-100">
        <div className="flex flex-col items-center">
          <div className="bg-primary-50 p-4 rounded-full mb-4">
            <ImagePlus className="h-8 w-8 text-primary-500" />
          </div>
          <p className="text-gray-600 mb-4">No images uploaded yet. Upload some images to get started.</p>
          <Button
            onClick={() => (window.location.href = "/upload")}
            className="rounded-full bg-primary-500 hover:bg-primary-600"
          >
            Upload Images
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {images.map((image) => (
        <Card key={image.id} className="lazygram-card border-0 overflow-hidden">
          <div className="aspect-square relative">
            <img src={image.url || "/placeholder.svg"} alt="Uploaded content" className="w-full h-full object-cover" />
            {image.scheduled && (
              <div className="absolute top-3 right-3 bg-primary-500 text-white text-xs px-3 py-1 rounded-full shadow-md">
                Scheduled
              </div>
            )}
          </div>
          <CardContent className="p-5">
            {editingId === image.id ? (
              <div className="space-y-3">
                <Textarea
                  value={editedCaption}
                  onChange={(e) => setEditedCaption(e.target.value)}
                  placeholder="Caption"
                  className="min-h-[100px] rounded-xl border-gray-200 focus:border-primary-500 focus:ring-primary-500"
                />
                <Textarea
                  value={editedHashtags}
                  onChange={(e) => setEditedHashtags(e.target.value)}
                  placeholder="Hashtags (space separated)"
                  className="min-h-[60px] rounded-xl border-gray-200 focus:border-primary-500 focus:ring-primary-500"
                />
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-gray-800">{cleanCaption(image.caption)}</p>
                <div className="flex flex-wrap gap-1.5">
                  {image.hashtags.map((tag, i) => (
                    <span key={i} className="lazygram-tag">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between p-5 pt-0">
            <div className="flex flex-wrap gap-2">
              {editingId === image.id ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleSave(image.id)}
                  className="rounded-full border-primary-500 text-primary-500 hover:bg-primary-50"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEdit(image)}
                  className="rounded-full border-gray-200 text-gray-700 hover:bg-gray-50"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}

              {editingId !== image.id && (
                <>
                  <Dialog open={schedulingId === image.id} onOpenChange={(open) => !open && setSchedulingId(null)}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openScheduleDialog(image)}
                        disabled={postingId === image.id}
                        className="rounded-full border-gray-200 text-gray-700 hover:bg-gray-50"
                      >
                        <Calendar className="h-4 w-4 mr-2" />
                        {image.scheduled ? "Reschedule" : "Schedule"}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="rounded-2xl">
                      <DialogHeader>
                        <DialogTitle>Schedule Post</DialogTitle>
                        <DialogDescription>
                          Choose when you want this post to be published to Instagram.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="schedule-time">Date and Time</Label>
                          <Input
                            id="schedule-time"
                            type="datetime-local"
                            value={scheduledTime}
                            onChange={(e) => setScheduledTime(e.target.value)}
                            className="rounded-xl"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setSchedulingId(null)} className="rounded-full">
                          Cancel
                        </Button>
                        <Button onClick={handleSchedule} className="rounded-full bg-primary-500 hover:bg-primary-600">
                          Schedule Post
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => handlePostNow(image)}
                    disabled={postingId === image.id}
                    className="rounded-full bg-primary-500 hover:bg-primary-600"
                  >
                    {postingId === image.id ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Posting...
                      </>
                    ) : (
                      <>
                        <Instagram className="h-4 w-4 mr-2" />
                        Post Now
                      </>
                    )}
                  </Button>
                </>
              )}
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleDelete(image.id)}
              disabled={postingId === image.id || editingId === image.id}
              className="rounded-full hover:bg-red-50 hover:text-red-500"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

