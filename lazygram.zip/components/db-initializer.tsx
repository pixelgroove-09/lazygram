"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2, Database } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function DbInitializer() {
  const [loading, setLoading] = useState(false)

  const handleInitDb = async () => {
    try {
      setLoading(true)

      // Get the admin API key from the user
      const apiKey = prompt("Enter your admin API key:")

      if (!apiKey) {
        toast({
          title: "Initialization cancelled",
          description: "Admin API key is required to initialize the database.",
          variant: "destructive",
        })
        return
      }

      // Call the database initialization endpoint
      const response = await fetch("/api/db/init", {
        headers: {
          Authorization: `Bearer ${apiKey}`,
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to initialize database")
      }

      const data = await response.json()

      toast({
        title: "Database initialized",
        description: "Database tables have been created successfully.",
      })
    } catch (error) {
      console.error("Database initialization error:", error)
      toast({
        title: "Initialization failed",
        description: error.message || "Failed to initialize database",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button onClick={handleInitDb} disabled={loading} variant="outline" size="sm">
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Initializing...
        </>
      ) : (
        <>
          <Database className="mr-2 h-4 w-4" />
          Initialize Database
        </>
      )}
    </Button>
  )
}

