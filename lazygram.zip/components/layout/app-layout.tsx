"use client"

import type { ReactNode } from "react"
import { usePathname, useRouter } from "next/navigation"
import Link from "next/link"
import { Instagram, LayoutDashboard, Upload, Calendar, Settings, LogOut, TestTube } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Toaster } from "@/components/ui/toaster"

interface AppLayoutProps {
  children: ReactNode
}

export default function AppLayout({ children }: AppLayoutProps) {
  const pathname = usePathname()
  const router = useRouter()

  const navItems = [
    { name: "Dashboard", href: "/dashboard", icon: <LayoutDashboard className="h-4 w-4 mr-2" /> },
    { name: "Upload", href: "/upload", icon: <Upload className="h-4 w-4 mr-2" /> },
    { name: "Schedule", href: "/schedule", icon: <Calendar className="h-4 w-4 mr-2" /> },
    { name: "Test Post", href: "/instagram-test", icon: <TestTube className="h-4 w-4 mr-2" /> },
    { name: "Settings", href: "/settings", icon: <Settings className="h-4 w-4 mr-2" /> },
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <Link href="/dashboard" className="flex items-center">
            <Instagram className="h-6 w-6 mr-2 text-primary-500" />
            <h1 className="text-xl font-bold bg-gradient-to-r from-primary-500 to-primary-700 bg-clip-text text-transparent">
              Lazygram
            </h1>
          </Link>

          <nav className="flex items-center space-x-2">
            {navItems.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button
                  variant={pathname === item.href ? "default" : "ghost"}
                  size="sm"
                  className={`hidden md:flex rounded-full ${
                    pathname === item.href
                      ? "bg-primary-500 hover:bg-primary-600 text-white"
                      : "hover:bg-primary-50 text-gray-700"
                  }`}
                >
                  {item.icon}
                  {item.name}
                </Button>
                <Button
                  variant={pathname === item.href ? "default" : "ghost"}
                  size="icon"
                  className={`md:hidden rounded-full ${
                    pathname === item.href
                      ? "bg-primary-500 hover:bg-primary-600 text-white"
                      : "hover:bg-primary-50 text-gray-700"
                  }`}
                >
                  {item.icon}
                </Button>
              </Link>
            ))}

            <Button
              variant="outline"
              size="sm"
              className="hidden md:flex text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full ml-2"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="md:hidden text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full ml-2"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </nav>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 container mx-auto py-8 px-4">{children}</main>

      {/* Footer */}
      <footer className="bg-white border-t py-6">
        <div className="container mx-auto px-4 text-center">
          <div className="flex flex-col items-center justify-center">
            <div className="flex items-center mb-4">
              <Instagram className="h-5 w-5 mr-2 text-primary-500" />
              <span className="font-bold text-lg bg-gradient-to-r from-primary-500 to-primary-700 bg-clip-text text-transparent">
                Lazygram
              </span>
            </div>
            <p className="text-sm text-gray-500 mb-4">Automate your Instagram posting with AI-generated captions</p>
            <div className="flex space-x-4">
              <Link href="/dashboard" className="text-sm text-gray-600 hover:text-primary-500">
                Dashboard
              </Link>
              <Link href="/upload" className="text-sm text-gray-600 hover:text-primary-500">
                Upload
              </Link>
              <Link href="/schedule" className="text-sm text-gray-600 hover:text-primary-500">
                Schedule
              </Link>
              <Link href="/settings" className="text-sm text-gray-600 hover:text-primary-500">
                Settings
              </Link>
            </div>
            <p className="text-xs text-gray-400 mt-6">© {new Date().getFullYear()} Lazygram. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Toast notifications */}
      <Toaster />
    </div>
  )
}

