"use client"

import { useState, useEffect } from "react"
import { Save, Trash2, Plus, Edit } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { getSavedPrompts, savePrompt, deletePrompt } from "@/app/actions/prompt-actions"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Skeleton } from "@/components/ui/skeleton"

interface SavedPrompt {
  id: string
  name: string
  prompt: string
  createdAt: string
}

export default function ThematicPromptSettings() {
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>([])
  const [loading, setLoading] = useState(true)
  const [newPromptDialogOpen, setNewPromptDialogOpen] = useState(false)
  const [editingPromptId, setEditingPromptId] = useState<string | null>(null)
  const [promptName, setPromptName] = useState("")
  const [promptText, setPromptText] = useState("")
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    loadSavedPrompts()
  }, [])

  const loadSavedPrompts = async () => {
    try {
      setLoading(true)
      const prompts = await getSavedPrompts()
      setSavedPrompts(prompts)
    } catch (error) {
      console.error("Failed to load saved prompts:", error)
      toast({
        title: "Error loading prompts",
        description: "Could not load your saved prompts. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSavePrompt = async () => {
    try {
      setSaving(true)

      if (!promptName.trim()) {
        toast({
          title: "Name required",
          description: "Please provide a name for your prompt.",
          variant: "destructive",
        })
        return
      }

      if (!promptText.trim()) {
        toast({
          title: "Prompt required",
          description: "Please provide a prompt to save.",
          variant: "destructive",
        })
        return
      }

      await savePrompt(promptName, promptText)
      await loadSavedPrompts()

      setNewPromptDialogOpen(false)
      setEditingPromptId(null)
      setPromptName("")
      setPromptText("")

      toast({
        title: "Prompt saved",
        description: "Your prompt has been saved successfully.",
      })
    } catch (error) {
      console.error("Failed to save prompt:", error)
      toast({
        title: "Save failed",
        description: "Could not save your prompt. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleDeletePrompt = async (id: string) => {
    if (!confirm("Are you sure you want to delete this prompt?")) return

    try {
      await deletePrompt(id)
      await loadSavedPrompts()

      toast({
        title: "Prompt deleted",
        description: "Your saved prompt has been deleted.",
      })
    } catch (error) {
      console.error("Failed to delete prompt:", error)
      toast({
        title: "Delete failed",
        description: "Could not delete your prompt. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEditPrompt = (prompt: SavedPrompt) => {
    setEditingPromptId(prompt.id)
    setPromptName(prompt.name)
    setPromptText(prompt.prompt)
    setNewPromptDialogOpen(true)
  }

  const handleAddNewPrompt = () => {
    setEditingPromptId(null)
    setPromptName("")
    setPromptText("")
    setNewPromptDialogOpen(true)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date)
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Thematic Prompts</CardTitle>
          <CardDescription>Manage your saved thematic prompts for caption generation</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex justify-between items-start p-4 border rounded-md">
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-5 w-1/3" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Thematic Prompts</CardTitle>
        <CardDescription>Manage your saved thematic prompts for caption generation</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {savedPrompts.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No saved prompts yet. Create your first prompt to get started.</p>
            </div>
          ) : (
            savedPrompts.map((prompt) => (
              <div key={prompt.id} className="flex justify-between items-start p-4 border rounded-md">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">{prompt.name}</h3>
                    <span className="text-xs text-muted-foreground">{formatDate(prompt.createdAt)}</span>
                  </div>
                  <p className="text-sm whitespace-pre-wrap">{prompt.prompt}</p>
                </div>
                <div className="flex space-x-2 ml-4">
                  <Button variant="ghost" size="icon" onClick={() => handleEditPrompt(prompt)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDeletePrompt(prompt.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>

        <Dialog open={newPromptDialogOpen} onOpenChange={setNewPromptDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingPromptId ? "Edit Prompt" : "Create New Prompt"}</DialogTitle>
              <DialogDescription>
                {editingPromptId
                  ? "Update your thematic prompt for caption generation"
                  : "Create a new thematic prompt for caption generation"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="prompt-name">Prompt Name</Label>
                <Input
                  id="prompt-name"
                  placeholder="e.g., Professional Business, Travel Adventure"
                  value={promptName}
                  onChange={(e) => setPromptName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="prompt-text">Prompt</Label>
                <Textarea
                  id="prompt-text"
                  placeholder="Describe the theme or style for your captions..."
                  value={promptText}
                  onChange={(e) => setPromptText(e.target.value)}
                  className="min-h-[150px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setNewPromptDialogOpen(false)} disabled={saving}>
                Cancel
              </Button>
              <Button onClick={handleSavePrompt} disabled={saving}>
                {saving ? (
                  "Saving..."
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Prompt
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
      <CardFooter>
        <Button onClick={handleAddNewPrompt} className="w-full">
          <Plus className="mr-2 h-4 w-4" />
          Create New Prompt
        </Button>
      </CardFooter>
    </Card>
  )
}

